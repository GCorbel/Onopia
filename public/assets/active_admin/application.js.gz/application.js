/* Active Admin JS */
$(function(){$(".datepicker").datepicker({dateFormat:"yy-mm-dd"}),$(".clear_filters_btn").click(function(){return window.location.search="",!1})});